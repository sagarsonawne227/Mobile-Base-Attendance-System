# Mobile-Attendance-System
  Mobile attendance system is an android application for managing student's lectures and attendance by college professor.
This project was completed in University of Arkansas, Litle Rock as an academic project. All the attendance related operations 
can be carried offline as the data in saved in mobile's SQLite Database. After the end of semester, the application calculates
each student's attendance percentage for enrolled lectures and total can also be e-mailed in order to have a hard copy of 
attendance. 
