package com.assignment.mbas;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class AboutProject extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout for this activity to display "About Project" details
        setContentView(R.layout.about_project);  // Ensure the layout file is activity_about_project.xml
    }
}
